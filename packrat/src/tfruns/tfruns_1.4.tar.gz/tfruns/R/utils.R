is_windows <- function() {
  identical(.Platform$OS.type, "windows")
}
