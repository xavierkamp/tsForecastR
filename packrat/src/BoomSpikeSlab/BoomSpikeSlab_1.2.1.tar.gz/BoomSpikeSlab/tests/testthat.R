library(testthat)
library(BoomSpikeSlab)
library(Boom)

test_check("BoomSpikeSlab")
