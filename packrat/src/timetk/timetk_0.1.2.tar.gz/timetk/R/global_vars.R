globalVariables(c("index", "index.num", "y", "yhat", "week", "mday"))
