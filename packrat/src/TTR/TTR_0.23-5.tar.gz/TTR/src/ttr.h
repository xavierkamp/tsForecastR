#ifndef _TTR_H_
#define _TTR_H_

#include <Rinternals.h>

/* imported from xts */
SEXP (*xts_na_check)(SEXP, SEXP);
#endif
